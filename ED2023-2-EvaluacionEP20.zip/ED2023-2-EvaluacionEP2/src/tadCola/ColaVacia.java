package tadCola;

@SuppressWarnings("serial")
public class ColaVacia extends Exception {
    public ColaVacia (final String msg) {
        super (msg);
    }
}
