import java.util.Random;

import algoritmos.Algoritmos;
import arbolBinario.Arbol;
import arbolBinario.ArbolAVL;
import arbolBinario.ArbolBB;
import arbolBinario.NodoArbol;
import tadCola.Cola;
import tadCola.TadCola;

public class Principal {

	public static void main(String[] args) {
		Character letra=83;
		ArbolAVL<Character> avl = new ArbolAVL<Character>("Mi AVL", letra);
		int n=9;

		for(int i=2; i<=n; ++i) {			
			letra = Algoritmos.letraMayAleatoria();
			if(!avl.buscar(letra))
				avl.insertar(letra);
			else
				--i;		
		}
		avl.listarAmplitudNiveles();
		letra = aleatorio(avl);
		System.out.println("Se obtiene un dato aleatorio del �rbol: " + letra);
		System.out.println("El dato " + letra + " est� en el nivel " + (letra!=null?avl.nivel(letra):""));
		System.out.println("Cola con los datos ordenados");
		ABBToCola(avl).imprimirCola();
	}
	
	//Metodo Generico Recursivo que retorna un dato aleatorio de un arbol binario cualquiera
	
	public static <T extends Comparable<T>> T aleatorio(Arbol<T> arbol) {
		if (arbol.getRaiz() != null) {
			return aleatorioRecursivo(arbol.getRaiz() );
		}
		return null;
	}
	
	private static <T extends Comparable<T>> T aleatorioRecursivo(NodoArbol<T> arbol) {
		Random random = new Random();
		int nodoIzquierdo = tama�oArbol(arbol.getIz());
		int nodoDerecho = tama�oArbol(arbol.getDe());
		int nodosDelArbol = nodoIzquierdo + nodoDerecho + 1;
		int randomIndex = random.nextInt(nodosDelArbol);

		if (randomIndex < nodoIzquierdo) {
			return aleatorioRecursivo(arbol.getIz());
		} else if (randomIndex == nodoIzquierdo) {
			return arbol.getClave();
		} else {
			return aleatorioRecursivo(arbol.getDe());
		}
	}
	
	private static <T extends Comparable<T>> int tama�oArbol(NodoArbol<T> arbol) {
		if (arbol == null) {
			return 0;
		}
		return 1 + tama�oArbol(arbol.getIz()) + tama�oArbol(arbol.getDe());
	}
	
	//Metodo Generico Recursivo que retorna una Cola ordenada con los datos de un ArbolBB
	
	public static <T extends Comparable<T>> Cola<T> ABBToCola(ArbolBB<T> arbol) {
		if(arbol == null) {
			return null;
		} 
		Cola<T> cola = new TadCola<>();
		return ABBToColaRecursivo(arbol.getRaiz(), cola);
	}
	
	private static <T extends Comparable<T>> Cola<T> ABBToColaRecursivo(NodoArbol<T> arbol, Cola<T> cola) {
		if(arbol!=null) {			
			ABBToColaRecursivo(arbol.getIz(), cola);
			cola.encolar(arbol.getClave());
			ABBToColaRecursivo(arbol.getDe(), cola);		
		}
		return cola;
		
	}
	
}
