package Algoritmos;

/**
 * @author Dalton
 */
import tadLista.Lista;
import tadLista.TadLista;

public class AlgoritmosListas {
	
	public static <T> void insertarAlPrincipio(Lista<T> lista, T dato) {
		if(lista!=null) {
			lista.crearNodo();
			lista.asignarClave(dato);
		}
	}
	
	public static <T> int contar(Lista<T> lista) {
		if(lista!=null) {
			Lista<T> aux =new TadLista<T>();
			aux.asignarReferencia(lista.devolverReferencia());
			return contarR(aux);
		}
		else
			return -1;
	}
	
	private static <T> int contarR(Lista<T>aux) {
		if(!aux.esNulo()) {
			aux.asignarReferencia(aux.devolverSiguiente());
			return 1+contarR(aux);
		}
		else
			return 0;
	}
	
	public static <T> void eliminarPrimero(Lista<T> lista){
		if(lista!=null && !lista.esNulo()) {
			lista.asignarReferencia(lista.devolverSiguiente());
			
		}
	}
	
	public static <T> void insertarAlFinal(Lista<T> lista, T dato) {
		if(lista != null) {
			if(!lista.esNulo()) {
				Lista<T> aux = new TadLista<T>();
				aux.asignarReferencia(lista.devolverReferencia());
				insertarAlFinalR(aux, dato);
			}else {
				insertarAlPrincipio(lista, dato);
			}
		}
	}
	private static <T> void insertarAlFinalR(Lista<T> aux, T dato) {
		if(aux.devolverSiguiente()!=null) {
			aux.asignarReferencia(aux.devolverSiguiente());
			insertarAlFinalR(aux, dato);
		}else {
			Lista<T> aux2 = new TadLista<>();
			insertarAlPrincipio(aux2, dato);
			aux.asignarReferenciaSiguiente(aux2.devolverReferencia());
		}
	}
	
	public static <T> void duplicarLista1(Lista<T> ListaO, Lista<T> ListaD) {
		if(ListaO != null && ListaD != null) {
			Lista<T> aux =new TadLista<T>();
			aux.asignarReferencia(ListaO.devolverReferencia()); //apunte al primero
			ListaD.asignarNulo();
			duplicarLista1R(aux, ListaD);
		}
	}
	private static <T> void duplicarLista1R(Lista<T> aux, Lista<T> ListaD) {
		if(!aux.esNulo()) {
			insertarAlFinal(ListaD, aux.devolverClave()); //insetar dato a la segunda lista
			aux.asignarReferencia(aux.devolverSiguiente()); //avanzar
			duplicarLista1R(aux, ListaD); //repetir
		}
		}
	
	public static <T> void duplicarLista2(Lista<T> ListaO, Lista<T> ListaD) {
		if(ListaO != null && ListaD != null) {
			Lista<T> aux =new TadLista<T>();
			aux.asignarReferencia(ListaO.devolverReferencia()); //apunte al primero
			ListaD.asignarNulo();
			duplicarLista2R(aux, ListaD);
		}
	}
	
	//se utilza con las llamadas recursivas (elemen) que a la vuelta va guardando las claves 
	private static <T> void duplicarLista2R(Lista<T> aux, Lista<T> ListaD) {
		T elem;
		if(!aux.esNulo()) {
			elem = aux.devolverClave(); //guarda clave o dato
			aux.asignarReferencia(aux.devolverSiguiente()); //avanzar
			duplicarLista2R(aux, ListaD); //repite
			insertarAlPrincipio(ListaD, elem); //insertar al principio los elementos guardados
		}
	}

	
	public static <T extends Comparable<T>> boolean buscar(Lista<T> lista,T dato) { //T extends Comparable<T>> para comparar datos
		if(lista != null) {
			Lista<T> aux= new TadLista<T>(); //crea una nueva lista
			aux.asignarReferencia(lista.devolverReferencia()); //asignar referencia a la lista aux al primer nodo de la lista
			return buscarR(aux, dato); 
			}
		else 
			return false;
	}
	
	private static <T extends Comparable<T> > boolean buscarR(Lista<T> aux, T dato) {
		boolean resul = false;
		if(!aux.esNulo()) { //si el auxiliar es null
			if(aux.devolverClave().compareTo(dato)==0) { // ==0 quiere decir comparable
				resul = true;
			}
			else {
				aux.asignarReferencia(aux.devolverSiguiente());
				resul = buscarR(aux, dato);
			}
		}
		return resul;
	}	
}