/**
 * @author Dalton
 */

import Algoritmos.AlgoritmosListas;	
import tadLista.Lista;
import tadLista.TadLista;
public class PruebaTadLista {

	public static void main(String[] args) {
		Lista<Integer> lista = new TadLista<>("Mi Lista");
		Lista<Integer> lista1 = new TadLista<>("Mi Lista copia 1");
		Lista<Integer> lista2 = new TadLista<>("Mi Lista copia 2");
		
		
		System.out.println("Insertando datos al principio se crea la lista: 8, 4, 3, 7");
		AlgoritmosListas.insertarAlPrincipio(lista, 7);
		AlgoritmosListas.insertarAlPrincipio(lista, 3);
		AlgoritmosListas.insertarAlPrincipio(lista, 4);
		AlgoritmosListas.insertarAlPrincipio(lista, 8);
		lista.imprimirLista();
		System.out.println("");
		
		System.out.println("Numero de elementos en la lista "+ lista.getNombre()+": "+AlgoritmosListas.contar(lista));
		System.out.println("");
		
		System.out.println("Se elimina el primer elemento de la lista :");
		AlgoritmosListas.eliminarPrimero(lista);
		lista.imprimirLista();
		System.out.println("");
		
		System.out.println("Se inserte al final de la lista el 99 :");
		AlgoritmosListas.insertarAlFinal(lista, 99);
		lista.imprimirLista();
		System.out.println("");
		
		System.out.println("Se copia la lista. Metodo 1");
		AlgoritmosListas.duplicarLista1(lista, lista1);
		lista1.imprimirLista();
		System.out.println("");
		
		
		System.out.println("Se copia la lista. Metodo 2");
		AlgoritmosListas.duplicarLista2(lista, lista2);
		lista2.imprimirLista();
		System.out.println("");
		
		System.out.println("Se busca el dato 4: "+ (AlgoritmosListas.buscar(lista, 4)?"ENCONTRADO":"NO ENCONTRADO"));
		System.out.println("Se busca el dato 5: "+ (AlgoritmosListas.buscar(lista,5)?"ENCONTRADO":"NO ENCONTRADO"));

	}

}