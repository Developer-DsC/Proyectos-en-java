package tadCola;

public class ColaVacia extends Exception {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ColaVacia(final String msg) {
        super (msg);
    }
}
